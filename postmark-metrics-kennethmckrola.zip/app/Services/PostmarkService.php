<?php

namespace App\Services;

use Postmark\PostmarkClient;

class PostmarkService
{
    public static function send($mailTo, $emailData)
    {
        $client = new PostmarkClient("1c3abf02-bd13-48f3-ab56-3b0a778c66d2");
        $fromEmail = "interviews@cztester.com";
        $toEmail = "*@cztester.com";
        $subject = "Hello from Postmark";
        $htmlBody = "<strong>Hello</strong> dear Postmark user.";
        $textBody = "Hello dear Postmark user.";
        $tag = "example-email-tag";
        $trackOpens = true;
        $trackLinks = "None";
        $messageStream = "outbound";
        
        // Send an email:
        $sendResult = $client->sendEmail(
        $fromEmail,
        $toEmail,
        $subject,
        $htmlBody,
        $textBody,
        $tag,
        $trackOpens,
        NULL, // Reply To
        NULL, // CC
        NULL, // BCC
        NULL, // Header array
        NULL, // Attachment array
        $trackLinks,
        NULL, // Metadata array
        $messageStream
        );
    }
}